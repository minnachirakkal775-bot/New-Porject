from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'dev-secret-key'

# ---------------- DATABASE SETUP ----------------
DB_NAME = 'disaster_management.db'

def get_db_connection():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    if not os.path.exists(DB_NAME):
        conn = get_db_connection()
        cur = conn.cursor()
        # Users table
        cur.execute('''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL
        )
        ''')
        # Disasters table
        cur.execute('''
        CREATE TABLE disasters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            location TEXT NOT NULL,
            date TEXT NOT NULL,
            severity TEXT,
            description TEXT
        )
        ''')
        # Volunteers table
        cur.execute('''
        CREATE TABLE volunteers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            contact TEXT,
            disaster_id INTEGER,
            role TEXT,
            FOREIGN KEY (disaster_id) REFERENCES disasters(id)
        )
        ''')
        # Resources table
        cur.execute('''
        CREATE TABLE resources (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT,
            quantity INTEGER,
            location TEXT
        )
        ''')
        # Requests table
        cur.execute('''
        CREATE TABLE requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            disaster_id INTEGER,
            request_detail TEXT,
            status TEXT DEFAULT 'Pending',
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (disaster_id) REFERENCES disasters(id)
        )
        ''')
        conn.commit()
        conn.close()
        create_sample_users()

# ---------------- AUTO-CREATE SAMPLE USERS ----------------
def create_sample_users():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        hashed = generate_password_hash("Minna2004")
        users = [
            ('admin1', hashed, 'admin'),
            ('responder1', hashed, 'responder'),
            ('citizen1', hashed, 'citizen')
        ]
        cur.executemany("INSERT INTO users(username,password,role) VALUES (?,?,?)", users)
        conn.commit()
    conn.close()

# ---------------- ROUTES ----------------
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        hashed_password = generate_password_hash(password)
        conn = get_db_connection()
        cur = conn.cursor()
        try:
            cur.execute("INSERT INTO users(username,password,role) VALUES (?,?,?)", (username, hashed_password, role))
            conn.commit()
            flash("Registration Successful!", "success")
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash("Username already exists!", "danger")
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE username=?", (username,))
        user = cur.fetchone()
        conn.close()
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role']
            flash("Login Successful!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid Username or Password", "danger")
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', username=session['username'], role=session['role'])

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully!", "info")
    return redirect(url_for('login'))

# ---------------- DISASTERS ----------------
@app.route('/disasters/view')
def view_disasters():
    conn = get_db_connection()
    disasters = conn.execute("SELECT * FROM disasters").fetchall()
    conn.close()
    return render_template('disasters.html', disasters=disasters)

@app.route('/disasters/add', methods=['GET','POST'])
def add_disaster():
    if request.method == 'POST':
        type_ = request.form['type']
        location = request.form['location']
        date = request.form['date']
        severity = request.form['severity']
        description = request.form['description']
        conn = get_db_connection()
        conn.execute("INSERT INTO disasters(type,location,date,severity,description) VALUES(?,?,?,?,?)",
                     (type_, location, date, severity, description))
        conn.commit()
        conn.close()
        flash("Disaster Added Successfully!", "success")
        return redirect(url_for('view_disasters'))
    return render_template('add_disaster.html')

# ---------------- VOLUNTEERS ----------------
@app.route('/volunteers/view')
def view_volunteers():
    conn = get_db_connection()
    volunteers = conn.execute("""
        SELECT v.id, v.name, v.contact, v.role, d.type, d.location 
        FROM volunteers v LEFT JOIN disasters d ON v.disaster_id=d.id
    """).fetchall()
    conn.close()
    return render_template('volunteers.html', volunteers=volunteers)

@app.route('/volunteers/add', methods=['GET','POST'])
def add_volunteer():
    conn = get_db_connection()
    disasters = conn.execute("SELECT * FROM disasters").fetchall()
    if request.method == 'POST':
        name = request.form['name']
        contact = request.form['contact']
        disaster_id = request.form['disaster_id']
        role = request.form['role']
        conn.execute("INSERT INTO volunteers(name,contact,disaster_id,role) VALUES(?,?,?,?)",
                     (name, contact, disaster_id, role))
        conn.commit()
        conn.close()
        flash("Volunteer Added Successfully!", "success")
        return redirect(url_for('view_volunteers'))
    conn.close()
    return render_template('add_volunteer.html', disasters=disasters)

@app.route('/volunteers/delete/<int:id>')
def delete_volunteer(id):
    conn = get_db_connection()
    conn.execute("DELETE FROM volunteers WHERE id=?", (id,))
    conn.commit()
    conn.close()
    flash("Volunteer Deleted Successfully!", "info")
    return redirect(url_for('view_volunteers'))

# ---------------- RESOURCES ----------------
@app.route('/resources/view')
def view_resources():
    conn = get_db_connection()
    resources = conn.execute("SELECT * FROM resources").fetchall()
    conn.close()
    return render_template('resources.html', resources=resources)

@app.route('/resources/add', methods=['GET','POST'])
def add_resource():
    if request.method == 'POST':
        name = request.form['name']
        type_ = request.form['type']
        quantity = request.form['quantity']
        location = request.form['location']
        conn = get_db_connection()
        conn.execute("INSERT INTO resources(name,type,quantity,location) VALUES(?,?,?,?)",
                     (name, type_, quantity, location))
        conn.commit()
        conn.close()
        flash("Resource Added Successfully!", "success")
        return redirect(url_for('view_resources'))
    return render_template('add_resource.html')

@app.route('/resources/delete/<int:id>')
def delete_resource(id):
    conn = get_db_connection()
    conn.execute("DELETE FROM resources WHERE id=?", (id,))
    conn.commit()
    conn.close()
    flash("Resource Deleted Successfully!", "info")
    return redirect(url_for('view_resources'))

# ---------------- REQUESTS ----------------
@app.route('/requests/add', methods=['GET','POST'])
def add_request():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db_connection()
    disasters = conn.execute("SELECT * FROM disasters").fetchall()
    if request.method == 'POST':
        disaster_id = request.form['disaster_id']
        request_detail = request.form['request_detail']
        user_id = session['user_id']
        conn.execute("INSERT INTO requests(user_id,disaster_id,request_detail) VALUES(?,?,?)",
                     (user_id, disaster_id, request_detail))
        conn.commit()
        conn.close()
        flash("Request Submitted Successfully!", "success")
        return redirect(url_for('view_requests'))
    conn.close()
    return render_template('add_request.html', disasters=disasters)

@app.route('/requests/view')
def view_requests():
    conn = get_db_connection()
    if session['role'] == 'citizen':
        requests_data = conn.execute("""
            SELECT r.id, d.type, d.location, r.request_detail, r.status 
            FROM requests r JOIN disasters d ON r.disaster_id=d.id
            WHERE r.user_id=?
        """, (session['user_id'],)).fetchall()
    else:
        requests_data = conn.execute("""
            SELECT r.id, u.username, d.type, d.location, r.request_detail, r.status 
            FROM requests r 
            JOIN disasters d ON r.disaster_id=d.id 
            JOIN users u ON r.user_id=u.id
        """).fetchall()
    conn.close()
    return render_template('requests.html', requests=requests_data)

@app.route('/requests/update/<int:id>/<status>')
def update_request(id, status):
    if session['role'] not in ['admin','responder']:
        flash("Unauthorized!", "danger")
        return redirect(url_for('view_requests'))
    conn = get_db_connection()
    conn.execute("UPDATE requests SET status=? WHERE id=?", (status, id))
    conn.commit()
    conn.close()
    flash("Request Status Updated!", "success")
    return redirect(url_for('view_requests'))

# ---------------- RUN APP ----------------
if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
