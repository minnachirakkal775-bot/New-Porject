# DisasterManagementApp
Flask-based Disaster Management System for alerts, volunteers, and resources.
