from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'dev-secret-key'

# ---------------- MySQL Configuration ----------------
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Minna2004'
app.config['MYSQL_DB'] = 'disaster_management'

mysql = MySQL(app)

# ---------------- AUTO-CREATE SAMPLE USERS ----------------
def create_sample_users():
    with mysql.connection.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM users")
        if cur.fetchone()[0] == 0:
            hashed = generate_password_hash("Minna2004")
            users = [
                ('admin1', hashed, 'admin'),
                ('responder1', hashed, 'responder'),
                ('citizen1', hashed, 'citizen')
            ]
            cur.executemany(
                "INSERT INTO users(username,password,role) VALUES(%s,%s,%s)",
                users
            )
            mysql.connection.commit()

# ---------------- ROUTES ----------------
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form['role']
        hashed_password = generate_password_hash(password)
        with mysql.connection.cursor() as cur:
            cur.execute(
                "INSERT INTO users(username,password,role) VALUES(%s,%s,%s)",
                (username, hashed_password, role)
            )
            mysql.connection.commit()
        flash("Registration Successful!", "success")
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with mysql.connection.cursor() as cur:
            cur.execute("SELECT * FROM users WHERE username=%s", (username,))
            user = cur.fetchone()
        if user and check_password_hash(user[2], password):
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['role'] = user[3]
            flash("Login Successful!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid Username or Password", "danger")
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', username=session['username'], role=session['role'])

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully!", "info")
    return redirect(url_for('login'))

# ---------------- DISASTERS ----------------
@app.route('/disasters/view')
def view_disasters():
    with mysql.connection.cursor() as cur:
        cur.execute("SELECT * FROM disasters")
        disasters = cur.fetchall()
    return render_template('disasters.html', disasters=disasters)

@app.route('/disasters/add', methods=['GET','POST'])
def add_disaster():
    if request.method == 'POST':
        type_ = request.form['type']
        location = request.form['location']
        date = request.form['date']
        severity = request.form['severity']
        description = request.form['description']
        with mysql.connection.cursor() as cur:
            cur.execute(
                "INSERT INTO disasters(type,location,date,severity,description) VALUES(%s,%s,%s,%s,%s)",
                (type_, location, date, severity, description)
            )
            mysql.connection.commit()
        flash("Disaster Added Successfully!", "success")
        return redirect(url_for('view_disasters'))
    return render_template('add_disaster.html')

# ---------------- VOLUNTEERS ----------------
@app.route('/volunteers/view')
def view_volunteers():
    with mysql.connection.cursor() as cur:
        cur.execute("""SELECT v.id, v.name, v.contact, v.role, d.type, d.location 
                       FROM volunteers v LEFT JOIN disasters d ON v.disaster_id=d.id""")
        volunteers = cur.fetchall()
    return render_template('volunteers.html', volunteers=volunteers)

@app.route('/volunteers/add', methods=['GET','POST'])
def add_volunteer():
    with mysql.connection.cursor() as cur:
        cur.execute("SELECT * FROM disasters")
        disasters = cur.fetchall()
    if request.method == 'POST':
        name = request.form['name']
        contact = request.form['contact']
        disaster_id = request.form['disaster_id']
        role = request.form['role']
        with mysql.connection.cursor() as cur:
            cur.execute(
                "INSERT INTO volunteers(name,contact,disaster_id,role) VALUES(%s,%s,%s,%s)",
                (name, contact, disaster_id, role)
            )
            mysql.connection.commit()
        flash("Volunteer Added Successfully!", "success")
        return redirect(url_for('view_volunteers'))
    return render_template('add_volunteer.html', disasters=disasters)

@app.route('/volunteers/delete/<int:id>')
def delete_volunteer(id):
    with mysql.connection.cursor() as cur:
        cur.execute("DELETE FROM volunteers WHERE id=%s", (id,))
        mysql.connection.commit()
    flash("Volunteer Deleted Successfully!", "info")
    return redirect(url_for('view_volunteers'))

# ---------------- RESOURCES ----------------
@app.route('/resources/view')
def view_resources():
    with mysql.connection.cursor() as cur:
        cur.execute("SELECT * FROM resources")
        resources = cur.fetchall()
    return render_template('resources.html', resources=resources)

@app.route('/resources/add', methods=['GET','POST'])
def add_resource():
    if request.method == 'POST':
        name = request.form['name']
        type_ = request.form['type']
        quantity = request.form['quantity']
        location = request.form['location']
        with mysql.connection.cursor() as cur:
            cur.execute(
                "INSERT INTO resources(name,type,quantity,location) VALUES(%s,%s,%s,%s)",
                (name, type_, quantity, location)
            )
            mysql.connection.commit()
        flash("Resource Added Successfully!", "success")
        return redirect(url_for('view_resources'))
    return render_template('add_resource.html')

@app.route('/resources/delete/<int:id>')
def delete_resource(id):
    with mysql.connection.cursor() as cur:
        cur.execute("DELETE FROM resources WHERE id=%s", (id,))
        mysql.connection.commit()
    flash("Resource Deleted Successfully!", "info")
    return redirect(url_for('view_resources'))

# ---------------- REQUESTS ----------------
@app.route('/requests/add', methods=['GET','POST'])
def add_request():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    with mysql.connection.cursor() as cur:
        cur.execute("SELECT * FROM disasters")
        disasters = cur.fetchall()
    if request.method == 'POST':
        disaster_id = request.form['disaster_id']
        request_detail = request.form['request_detail']
        user_id = session['user_id']
        with mysql.connection.cursor() as cur:
            cur.execute(
                "INSERT INTO requests(user_id,disaster_id,request_detail) VALUES(%s,%s,%s)",
                (user_id, disaster_id, request_detail)
            )
            mysql.connection.commit()
        flash("Request Submitted Successfully!", "success")
        return redirect(url_for('view_requests'))
    return render_template('add_request.html', disasters=disasters)

@app.route('/requests/view')
def view_requests():
    with mysql.connection.cursor() as cur:
        if session['role'] == 'citizen':
            cur.execute("""SELECT r.id, d.type, d.location, r.request_detail, r.status 
                           FROM requests r JOIN disasters d ON r.disaster_id=d.id 
                           WHERE r.user_id=%s""", (session['user_id'],))
        else:
            cur.execute("""SELECT r.id, u.username, d.type, d.location, r.request_detail, r.status 
                           FROM requests r JOIN disasters d ON r.disaster_id=d.id 
                           JOIN users u ON r.user_id=u.id""")
        requests_data = cur.fetchall()
    return render_template('requests.html', requests=requests_data)

@app.route('/requests/update/<int:id>/<status>')
def update_request(id, status):
    if session['role'] not in ['admin','responder']:
        flash("Unauthorized!", "danger")
        return redirect(url_for('view_requests'))
    with mysql.connection.cursor() as cur:
        cur.execute("UPDATE requests SET status=%s WHERE id=%s", (status, id))
        mysql.connection.commit()
    flash("Request Status Updated!", "success")
    return redirect(url_for('view_requests'))

# ---------------- RUN APP ----------------
if __name__ == '__main__':
    with app.app_context():
        create_sample_users()
    app.run(debug=True)